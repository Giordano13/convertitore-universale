"""Persistent history and named image/media workflows."""
import json
from pathlib import Path
from datetime import datetime,timezone
import uuid

class StateStore:
    def __init__(self,directory):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
    def read(self,name,default):
        try:return json.loads((self.directory/name).read_text(encoding='utf-8'))
        except (OSError,ValueError):return default
    def write(self,name,data):
        temporary=self.directory/(name+'.tmp')
        temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(self.directory/name)
    def history(self):return self.read('history.json',[])
    def add_history(self,job,success,result):
        rows=self.history();entry=dict(id=str(uuid.uuid4()),time=datetime.now(timezone.utc).isoformat(),job=job,success=success,result=result)
        if success and Path(result).is_file():entry['output_bytes']=Path(result).stat().st_size
        entry['input_bytes']=sum(Path(p).stat().st_size for p in job['sources'] if Path(p).is_file())
        rows.insert(0,entry);self.write('history.json',rows[:1000])
    def recipes(self):return self.read('recipes.json',{})
    def save_recipe(self,name,options):
        recipes=self.recipes();recipes[name]=options;self.write('recipes.json',recipes)
