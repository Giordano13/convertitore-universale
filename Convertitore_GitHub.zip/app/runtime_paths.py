"""Locate optional Windows tools and per-app OCR data after installation."""
from pathlib import Path
import sys,os,shutil

def distribution_root():
    return Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent

def media_executable(name):
    override=os.environ.get('FFMPEG_CMD' if name=='ffmpeg' else 'FFPROBE_CMD')
    if override and Path(override).is_file():return override
    found=shutil.which(name)
    if found:return found
    bases=[Path(os.environ.get('LOCALAPPDATA',''))/'Microsoft/WinGet',Path(os.environ.get('ProgramFiles','C:/Program Files'))/'WinGet'] if os.name=='nt' else []
    for base in bases:
        candidate=base/'Links'/(name+'.exe')
        if candidate.is_file():return str(candidate)
        for package in (base/'Packages').glob('Gyan.FFmpeg_*'):
            for candidate in package.glob('*/bin/'+name+'.exe'):
                if candidate.is_file():return str(candidate)
    raise RuntimeError(f'{name} non disponibile. Installa il componente Audio e video da Gestisci componenti.')

def tessdata_arguments(language):
    candidates=[]
    if os.environ.get('TESSDATA_PREFIX'):candidates.append(Path(os.environ['TESSDATA_PREFIX']))
    candidates.append(distribution_root()/'tessdata')
    if os.name=='nt':candidates.append(Path(os.environ.get('LOCALAPPDATA',''))/'Programs/ConvertitoreUniversale/tessdata')
    for directory in candidates:
        if all((directory/(name+'.traineddata')).is_file() for name in language.split('+')):
            return ['--tessdata-dir',str(directory)]
    return []

def component_script():
    root=distribution_root()
    return root/('maintenance' if getattr(sys,'frozen',False) else 'installer')/'install_components.ps1'

def release_config_path():
    return distribution_root()/'release/config.json'
