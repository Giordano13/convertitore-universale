# Convertitore Universale 2.1

Progetto desktop Windows in italiano. Tutte le conversioni e le funzioni
2.0 sono conservate; questa versione organizza installazione e aggiornamenti.

**Questo ZIP contiene sorgenti, modelli OCR e script. Il Setup.exe Windows
va ancora compilato e verificato su Windows o con il workflow incluso.**

## Avvio rapido

1. Estrai lo ZIP completo.
2. Apri **Setup.vbs**. Scegli FFmpeg, LibreOffice, Tesseract e italiano OCR.
3. Apri **Avvia.vbs**.

Setup.vbs è il setup dei sorgenti: prepara `.venv` e installa le librerie.
Usa Python 3.11–3.13 disponibile sul PC; se manca, propone l'installazione
tramite WinGet di Python 3.12. Servono Internet e Windows 10/11 con
Installazione app/WinGet. I programmi esterni possono chiedere conferma UAC.
Il setup non modifica la policy PowerShell permanente: il parametro Bypass
riguarda soltanto il processo che esegue gli script inclusi.

## Il setup per gli altri utenti

Esegui **CreaSetup.vbs** dopo Setup.vbs e dopo aver installato
[Inno Setup 6.3 o successivo](https://jrsoftware.org/isdl.php).
Il comando unico prepara PyInstaller, raccoglie licenze e compila Inno Setup.
I risultati sono in `output/`:

- `ConvertitoreUniversale-Setup-2.1.2.exe`: app inclusa, senza bisogno di Python.
- `ConvertitoreUniversale-Sorgenti-2.1.2.zip`: sorgenti della versione.
- `SHA256SUMS.txt`: hash dei risultati della build.

Il setup permette **Completa / Base / Personalizzata**, scelta dei componenti,
cartella di installazione, collegamento desktop e disinstallazione.
FFmpeg, LibreOffice e Tesseract sono installati tramite WinGet dalla sorgente
`winget`; non sono binari copiati dentro questo ZIP. L'app base si installa
nell'account corrente. Per i componenti esterni possono servire privilegi admin.
Se un componente fallisce, il setup lo segnala e lascia disponibile l'app base.
I modelli OCR inglese/italiano sono inclusi, verificati tramite SHA256 e attivati
solo quando selezionati. La cache dei modelli permette di aggiungerli in seguito.

**Componenti** nell'app permette di installare o aggiornare soltanto quelli
selezionati, con log. I componenti già presenti non vengono aggiornati dal setup;
per aggiornarli usa il pulsante dedicato. Disinstallare il convertitore non
rimuove FFmpeg/LibreOffice/Tesseract né cronologia e sequenze dell'utente.
Deselezionare un componente già installato non lo disinstalla.

## Aggiornamenti

Il setup mantiene AppId e cartella della versione precedente, quindi una
nuova versione può essere installata sopra quella vecchia. Dati e sequenze
rimangono nei dati locali dell'app. Una cartella sorgenti estratta dalla 2.0
non è un'installazione registrata: può essere tenuta come copia di riserva.

Nell'app, **Aggiornamenti** controlla il canale HTTPS, mostra le note, scarica
l'installer e ne verifica dimensione e SHA256. Il download può essere annullato.
L'installazione parte soltanto premendo **Installa e chiudi app**, con coda ferma.
Su Linux puoi verificare/scaricare; l'avvio del setup è disponibile su Windows.
Il controllo all'avvio è facoltativo e inizialmente disattivato.

Il canale è **vuoto finché non esiste il tuo repository o sito**: non c'è un
server fittizio. La configurazione va fatta prima di compilare la release pubblica.
Per GitHub: `python tools/configure_release.py --github proprietario/repository`.
Consulta [la guida alla pubblicazione](docs/PUBBLICAZIONE.md).

## Struttura

| Cartella | Contenuto |
| --- | --- |
| app | Programma, motori, grafica e gestione aggiornamenti |
| installer | Script Inno/PowerShell e modelli OCR con provenienza e licenza |
| release | Configurazione del canale; update.json viene generato dopo la build |
| tools | Setup sorgenti, compilazione, hash e preparazione versioni |
| docs | Manuale conversioni, pubblicazione e verifiche |
| tests | Conversioni, interfaccia e aggiornamenti |

Il workflow Windows incluso produce artifact da revisionare e non crea
release pubbliche. Le conversioni e i limiti dei formati sono descritti in
[docs/MANUALE_CONVERSIONI.md](docs/MANUALE_CONVERSIONI.md). Le prove della 2.1 sono in
[docs/VERIFICHE_2.1.md](docs/VERIFICHE_2.1.md).

## Test e uso su Linux/macOS

Installa `requirements.txt`, poi `python app/main.py`.
Test: `PYTHONPATH=app QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v`.
Build/verifica: `python tools/build_release.py --validate-only`.
La compilazione del setup e l'installazione guidata dei componenti richiedono Windows.

## Licenza del progetto

Copyright (c) 2026 Giordano13. Il codice del progetto e distribuito sotto GNU AGPLv3, senza garanzia. Il testo completo e in LICENSE. Le dipendenze mantengono le rispettive licenze.
