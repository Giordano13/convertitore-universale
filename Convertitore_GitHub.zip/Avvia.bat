@echo off
wscript.exe "%~dp0Avvia.vbs"
