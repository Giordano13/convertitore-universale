@echo off
wscript.exe "%~dp0Setup.vbs"
