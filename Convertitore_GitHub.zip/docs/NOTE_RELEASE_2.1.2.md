# Convertitore Universale 2.1.2

Convertitore per Windows con interfaccia grafica, conversioni in coda, audio/video, immagini, documenti, PDF e OCR. I formati disponibili dipendono dai componenti installati.

## Novita
- Installazione guidata con scelta di FFmpeg, LibreOffice e Tesseract.
- Avvio senza console e registri degli errori.
- Il setup prosegue quando i componenti sono gia installati.
- Controllo e download degli aggiornamenti con verifica SHA256.

## Installazione
Scarica l installer EXE dagli allegati della release, eseguilo e scegli i componenti. Gli installer esterni richiedono Internet e possono chiedere conferma amministratore.

Per usare i sorgenti: estrai lo ZIP, apri Setup.vbs e poi Avvia.vbs.

Questa versione va presentata come anteprima finche il Setup.exe non e stato provato su Windows. Il codice non permette di convertire qualsiasi file in qualsiasi formato: l interfaccia mostra le combinazioni supportate.
